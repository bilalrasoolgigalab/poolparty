import './general.js';
import './prices.js';
