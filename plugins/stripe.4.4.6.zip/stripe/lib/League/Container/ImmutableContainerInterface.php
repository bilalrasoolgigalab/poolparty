<?php

namespace SimplePay\Vendor\League\Container;

use SimplePay\Vendor\Interop\Container\ContainerInterface as InteropContainerInterface;

interface ImmutableContainerInterface extends InteropContainerInterface
{

}
