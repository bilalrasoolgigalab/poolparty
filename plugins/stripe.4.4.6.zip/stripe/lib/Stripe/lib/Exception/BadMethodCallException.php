<?php

namespace SimplePay\Vendor\Stripe\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
