<?php

namespace SimplePay\Vendor\Stripe\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
