<?php

namespace SimplePay\Vendor\Stripe\Exception\OAuth;

/**
 * The base interface for all SimplePay\Vendor\Stripe OAuth exceptions.
 */
interface ExceptionInterface extends \SimplePay\Vendor\Stripe\Exception\ExceptionInterface
{
}
