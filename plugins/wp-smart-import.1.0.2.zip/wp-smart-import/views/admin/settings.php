<?php  if (!defined('ABSPATH')) { exit; } ?>
<h1> <?php  wpsi_helper::_e ("Settings are currently Unavailable") ?> </h1>